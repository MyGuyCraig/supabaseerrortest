/*
  # Create Orders Management System

  1. New Tables
    - `orders`
      - `id` (uuid, primary key)
      - `order_number` (text, unique) - Human readable order number
      - `customer_info` (jsonb) - Customer details (name, email, phone, etc.)
      - `delivery_info` (jsonb) - Delivery address and instructions
      - `payment_info` (jsonb) - Payment method and details
      - `items` (jsonb) - Array of ordered items with details
      - `subtotal` (numeric) - Order subtotal amount
      - `delivery_charges` (numeric) - Delivery charges
      - `total` (numeric) - Total order amount
      - `status` (text) - Order status (pending, confirmed, processing, shipped, delivered, cancelled)
      - `payment_status` (text) - Payment status (pending, paid, cod_pending, failed)
      - `promo_code` (text) - Applied promo code if any
      - `promo_discount` (numeric) - Discount amount from promo code
      - `notes` (text) - Special instructions or notes
      - `created_at` (timestamp) - Order creation time
      - `updated_at` (timestamp) - Last update time

  2. Security
    - Enable RLS on `orders` table
    - Add policies for public access (since this is an e-commerce site)
    - Add indexes for better query performance

  3. Functions
    - Auto-update `updated_at` timestamp on row updates
</sql>

-- Create the orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  customer_info jsonb NOT NULL,
  delivery_info jsonb NOT NULL,
  payment_info jsonb NOT NULL,
  items jsonb NOT NULL,
  subtotal numeric DEFAULT 0 NOT NULL,
  delivery_charges numeric DEFAULT 0 NOT NULL,
  total numeric DEFAULT 0 NOT NULL,
  status text DEFAULT 'pending' NOT NULL,
  payment_status text DEFAULT 'pending' NOT NULL,
  promo_code text,
  promo_discount numeric DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (e-commerce site)
CREATE POLICY "Anyone can insert orders"
  ON orders
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public can read orders"
  ON orders
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can update orders"
  ON orders
  FOR UPDATE
  TO anon
  USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders (order_number);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders (payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders (created_at DESC);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();