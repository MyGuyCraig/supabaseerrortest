/*
  # Comprehensive Orders Management System

  1. New Tables
    - `orders` - Main orders table with all order information
      - `id` (uuid, primary key)
      - `order_number` (text, unique)
      - `customer_info` (jsonb) - Customer details
      - `delivery_info` (jsonb) - Delivery address
      - `payment_info` (jsonb) - Payment method details
      - `items` (jsonb) - Order items array
      - `subtotal` (numeric)
      - `delivery_charges` (numeric)
      - `total` (numeric)
      - `status` (text) - Order status
      - `payment_status` (text) - Payment status
      - `promo_code` (text, nullable)
      - `promo_discount` (numeric, nullable)
      - `notes` (text, nullable)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `orders` table
    - Add policies for public access (since no authentication required)
    - Add indexes for performance

  3. Functions
    - Auto-update `updated_at` timestamp
    - Order number generation
*/

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  customer_info jsonb NOT NULL,
  delivery_info jsonb NOT NULL,
  payment_info jsonb NOT NULL,
  items jsonb NOT NULL,
  subtotal numeric DEFAULT 0,
  delivery_charges numeric DEFAULT 0,
  total numeric DEFAULT 0,
  status text DEFAULT 'pending',
  payment_status text DEFAULT 'pending',
  promo_code text,
  promo_discount numeric DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no authentication required)
CREATE POLICY "Anyone can insert orders"
  ON orders
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public can read orders"
  ON orders
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can update orders"
  ON orders
  FOR UPDATE
  TO anon
  USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders (order_number);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders (payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders (created_at DESC);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();