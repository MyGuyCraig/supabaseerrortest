import { supabase } from '../lib/supabase';
import { Order } from '../types/order';
import { isSupabaseConfigured } from '../lib/supabase';

interface SupabaseOrderRow {
  id: string;
  order_number: string;
  customer_info: any;
  delivery_info: any;
  payment_info: any;
  items: any;
  subtotal: number;
  delivery_charges: number;
  total: number;
  status: string;
  payment_status: string;
  promo_code?: string;
  promo_discount?: number;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export class OrderService {
  // Create a new order in Supabase
  static async createOrder(order: Order): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
      console.warn('Supabase not configured, skipping database save');
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      console.error('Supabase client not initialized');
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      console.log('Attempting to save order to Supabase:', order.orderNumber);
      
      const { error } = await supabase
        .from('orders')
        .insert([{
          id: order.id,
          order_number: order.orderNumber,
          customer_info: order.customer,
          delivery_info: order.delivery,
          payment_info: order.payment,
          items: order.items,
          subtotal: order.subtotal,
          delivery_charges: order.deliveryCharges,
          total: order.total,
          status: order.status,
          payment_status: order.paymentStatus,
          promo_code: order.promoCode,
          promo_discount: order.promoDiscount || 0,
          notes: order.notes
        }]);

      if (error) {
        console.error('Error creating order:', error);
        return { success: false, error: error.message };
      }

      console.log('Order saved to Supabase successfully:', order.orderNumber);
      return { success: true };
    } catch (error) {
      console.error('Error creating order:', error);
      return { success: false, error: 'Failed to create order' };
    }
  }

  // Get all orders
  static async getAllOrders(): Promise<{ success: boolean; data?: Order[]; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching orders:', error);
        return { success: false, error: error.message };
      }

      // Transform Supabase data back to Order format
      const orders: Order[] = data.map((row: SupabaseOrderRow) => ({
        id: row.id,
        orderNumber: row.order_number,
        customer: row.customer_info,
        delivery: row.delivery_info,
        payment: row.payment_info,
        items: row.items,
        subtotal: row.subtotal,
        deliveryCharges: row.delivery_charges,
        codCharges: 0, // Legacy field
        total: row.total,
        status: row.status,
        paymentStatus: row.payment_status,
        createdAt: row.created_at,
        estimatedDelivery: '', // Legacy field
        notes: row.notes,
        promoCode: row.promo_code,
        promoDiscount: row.promo_discount
      }));

      return { success: true, data: orders };
    } catch (error) {
      console.error('Error fetching orders:', error);
      return { success: false, error: 'Failed to fetch orders' };
    }
  }

  // Update order status
  static async updateOrderStatus(orderId: string, status: Order['status']): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status })
        .eq('id', orderId);

      if (error) {
        console.error('Error updating order status:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Error updating order status:', error);
      return { success: false, error: 'Failed to update order status' };
    }
  }

  // Update payment status
  static async updatePaymentStatus(orderId: string, paymentStatus: Order['paymentStatus']): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { error } = await supabase
        .from('orders')
        .update({ payment_status: paymentStatus })
        .eq('id', orderId);

      if (error) {
        console.error('Error updating payment status:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Error updating payment status:', error);
      return { success: false, error: 'Failed to update payment status' };
    }
  }

  // Delete an order
  static async deleteOrder(orderId: string): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { error } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderId);

      if (error) {
        console.error('Error deleting order:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Error deleting order:', error);
      return { success: false, error: 'Failed to delete order' };
    }
  }

  // Get order by order number
  static async getOrderByNumber(orderNumber: string): Promise<{ success: boolean; data?: Order; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', orderNumber)
        .single();

      if (error) {
        console.error('Error fetching order:', error);
        return { success: false, error: error.message };
      }

      const order: Order = {
        id: (data as SupabaseOrderRow).id,
        orderNumber: (data as SupabaseOrderRow).order_number,
        customer: (data as SupabaseOrderRow).customer_info,
        delivery: (data as SupabaseOrderRow).delivery_info,
        payment: (data as SupabaseOrderRow).payment_info,
        items: (data as SupabaseOrderRow).items,
        subtotal: (data as SupabaseOrderRow).subtotal,
        deliveryCharges: (data as SupabaseOrderRow).delivery_charges,
        codCharges: 0,
        total: (data as SupabaseOrderRow).total,
        status: (data as SupabaseOrderRow).status,
        paymentStatus: (data as SupabaseOrderRow).payment_status,
        createdAt: (data as SupabaseOrderRow).created_at,
        estimatedDelivery: '',
        notes: (data as SupabaseOrderRow).notes,
        promoCode: (data as SupabaseOrderRow).promo_code,
        promoDiscount: (data as SupabaseOrderRow).promo_discount
      };

      return { success: true, data: order };
    } catch (error) {
      console.error('Error fetching order:', error);
      return { success: false, error: 'Failed to fetch order' };
    }
  }

  // Get orders by status
  static async getOrdersByStatus(status: Order['status']): Promise<{ success: boolean; data?: Order[]; error?: string }> {
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase not configured' };
    }
    
    if (!supabase) {
      return { success: false, error: 'Supabase client not initialized' };
    }
    
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('status', status)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching orders by status:', error);
        return { success: false, error: error.message };
      }

      const orders: Order[] = data.map((row: SupabaseOrderRow) => ({
        id: row.id,
        orderNumber: row.order_number,
        customer: row.customer_info,
        delivery: row.delivery_info,
        payment: row.payment_info,
        items: row.items,
        subtotal: row.subtotal,
        deliveryCharges: row.delivery_charges,
        codCharges: 0,
        total: row.total,
        status: row.status,
        paymentStatus: row.payment_status,
        createdAt: row.created_at,
        estimatedDelivery: '',
        notes: row.notes,
        promoCode: row.promo_code,
        promoDiscount: row.promo_discount
      }));

      return { success: true, data: orders };
    } catch (error) {
      console.error('Error fetching orders by status:', error);
      return { success: false, error: 'Failed to fetch orders by status' };
    }
  }
}