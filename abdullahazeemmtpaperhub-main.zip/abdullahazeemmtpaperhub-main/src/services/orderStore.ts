@@ .. @@
   // Update payment status
   static async updatePaymentStatus(orderId: string, paymentStatus: Order['paymentStatus']): Promise<{ success: boolean; error?: string }> {
+    if (!isSupabaseConfigured) {
+      return { success: false, error: 'Supabase not configured' };
+    }
+    
     try {