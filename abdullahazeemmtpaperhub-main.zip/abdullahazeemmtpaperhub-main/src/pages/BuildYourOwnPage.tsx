import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  BookOpen, 
  Plus,
  Minus,
  ShoppingCart,
  Mail,
  X,
  HelpCircle,
  Check,
  ChevronRight,
  Sparkles,
  Layers,
  Calendar,
  Package,
  Bookmark
} from 'lucide-react';
import { useCartStore } from '../stores/cartStore';
import toast from 'react-hot-toast';
import Confetti from 'react-confetti';

// Color constants for the teal theme
const COLORS = {
  teal: {
    primary: '#1EA1A1',
    light: '#E6F7F7',
    dark: '#178787',
    extraLight: '#F0FAFA'
  },
  complementary: {
    coral: '#FF6B6B',
    peach: '#FFA07A',
    gold: '#FFD166',
    mint: '#06D6A0',
    lavender: '#A882DD'
  },
  neutral: {
    white: '#FFFFFF',
    lightGray: '#F8FAFC',
    gray: '#E2E8F0',
    darkGray: '#64748B',
    black: '#1E293B'
  }
};

// --- DATA & TYPES (Keep your existing data and types) ---
type Level = 'o-level' | 'a-level' | 'igcse';
type Paper = 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'S1' | 'M1';
type Binding = 'none' | 'tape'; // Removed 'ring'

interface Subject {
  id: string;
  name: string;
  code: string;
  papers: Paper[];
}

interface PaperYearRange {
  paper: Paper;
  yearRange: {
    start: number;
    end: number;
  };
}

interface FormState {
  level: Level;
  subjects: string[];
  papers: Record<string, PaperYearRange[]>;
  binding: Binding;
  bindingOption: 'together' | 'separate';
  notes: string;
  customSubject: string;
}

// Pricing data
const pricing: Record<Level, Record<string, Record<string, number>>> = {
  'o-level': {
    'english': { 'P1': 250, 'P2': 130 },
    'english-lit': { 'P1': 255, 'P2': 130 },
    'env-mgmt': { 'P1': 175, 'P2': 170 },
    'food-nutrition': { 'P1': 290, 'P2': 290 },
    'pak-studies': { 'P1': 90, 'P2': 250 },
    'islamiyat': { 'P1': 315, 'P2': 290 },
    'math-d': { 'P1': 240, 'P2': 275 },
    'physics': { 'P1': 170, 'P2': 270, 'P4': 145 },
    'sociology': { 'P1': 145, 'P2': 180 },
    'global-persp': { 'P1': 90 },
    'urdu-1': { 'P1': 80, 'P2': 80 },
    'urdu-2': { 'P1': 175, 'P2': 175 },
    'travel-tour': { 'P1': 105, 'P2': 120 },
    'accounting': { 'P1': 120, 'P2': 330 },
    'add-math': { 'P1': 255, 'P2': 250 },
    'biology': { 'P1': 180, 'P2': 240, 'P4': 125 },
    'business': { 'P1': 290, 'P2': 290 },
    'chemistry': { 'P1': 160, 'P2': 255, 'P4': 190 },
    'comb-sci': { 'P1': 180, 'P2': 320 },
    'commerce': { 'P1': 120, 'P2': 305 },
    'comp-sci': { 'P1': 180, 'P2': 225 },
    'economics': { 'P1': 110, 'P2': 250 }
  },
  'a-level': {
    'accounting-al': { 'P1': 170, 'P2': 250, 'P3': 580 },
    'biology-al': { 'P1': 300, 'P2': 445, 'P3': 175, 'P4': 515, 'P5': 195 },
    'business-al': { 'P1': 265, 'P2': 375, 'P3': 590 },
    'chemistry-al': { 'P1': 215, 'P2': 270, 'P3': 195, 'P4': 350, 'P5': 155 },
    'comp-sci-al': { 'P1': 240, 'P2': 330, 'P3': 160, 'P4': 355 },
    'economics-al': { 'P1': 190, 'P2': 220, 'P3': 180, 'P4': 190 },
    'eng-lang-al': { 'P1': 225, 'P2': 110, 'P3': 160, 'P4': 110 },
    'eng-lit-al': { 'P3': 270, 'P4': 270, 'P5': 260, 'P6': 385 },
    'env-mgmt-al': { 'P1': 320, 'P2': 290 },
    'further-math-al': { 'P1': 305, 'P2': 335 },
    'history-al': { 'P1': 260, 'P2': 355, 'P3': 125, 'P4': 305 },
    'law-al': { 'P1': 140, 'P2': 170, 'P3': 130, 'P4': 125 },
    'math-al': { 'P1': 525, 'P3': 525, 'S1': 365, 'M1': 410 },
    'physics-al': { 'P1': 290, 'P2': 340, 'P3': 175, 'P4': 370, 'P5': 155 },
    'psychology-al': { 'P1': 320, 'P2': 395, 'P3': 400, 'P4': 340 },
    'sociology-al': { 'P1': 205, 'P2': 210, 'P3': 175 },
    'thinking-skills-al': { 'P1': 285, 'P2': 180, 'P3': 125, 'P4': 175 },
    'urdu-al': { 'P2': 210, 'P3': 210, 'P4': 210 }
  },
  'igcse': {
    'global-persp': { 'P1': 385 },
    'ict': { 'P1': 365 },
    'islamiyat': { 'P1': 320, 'P2': 300 },
    'math': { 'P1': 260, 'P4': 435 },
    'pak-studies': { 'P1': 60, 'P2': 125 },
    'physics': { 'P2': 270, 'P4': 285, 'P6': 255 },
    'sociology': { 'P1': 355, 'P2': 480 },
    'urdu-2': { 'P1': 100, 'P2': 100 },
    'accounting': { 'P1': 190, 'P2': 380 },
    'add-math': { 'P1': 365, 'P2': 350 },
    'biology': { 'P2': 240, 'P4': 445, 'P5': 250 },
    'business': { 'P1': 435, 'P2': 321 },
    'chemistry': { 'P1': 260, 'P2': 395, 'P4': 320, 'P6': 210 },
    'comp-sci': { 'P1': 290, 'P2': 365 },
    'economics': { 'P1': 160, 'P2': 395 },
    'eng-lang': { 'P1': 530, 'P2': 315 },
    'eng-2nd-lang': { 'P2': 330, 'P4': 145 },
    'env-mgmt': { 'P1': 435, 'P2': 450 },
    'geography': { 'P1': 200, 'P2': 250 }
  }
};

// Subjects data
const subjects: Record<Level, Subject[]> = {
  'o-level': [
    { id: 'urdu-1', name: 'Urdu – First Language', code: '3247', papers: ['P1', 'P2'] },
    { id: 'urdu-2', name: 'Urdu – Second Language', code: '3248', papers: ['P1', 'P2'] },
    { id: 'english', name: 'English Language', code: '1123', papers: ['P1', 'P2'] },
    { id: 'english-lit', name: 'Literature in English', code: '2010', papers: ['P1', 'P2'] },
    { id: 'biology', name: 'Biology', code: '5090', papers: ['P1', 'P2', 'P4'] },
    { id: 'chemistry', name: 'Chemistry', code: '5070', papers: ['P1', 'P2', 'P4'] },
    { id: 'physics', name: 'Physics', code: '5054', papers: ['P1', 'P2', 'P4'] },
    { id: 'math-d', name: 'Mathematics D', code: '4024', papers: ['P1', 'P2'] },
    { id: 'add-math', name: 'Additional Mathematics', code: '4037', papers: ['P1', 'P2'] },
    { id: 'comb-sci', name: 'Combined Science', code: '5129', papers: ['P1', 'P2', 'P3'] },
    { id: 'pak-studies', name: 'Pakistan Studies', code: '2059', papers: ['P1', 'P2'] },
    { id: 'islamiyat', name: 'Islamiyat', code: '2058', papers: ['P1', 'P2'] },
    { id: 'business', name: 'Business Studies', code: '7115', papers: ['P1', 'P2'] },
    { id: 'economics', name: 'Economics', code: '2281', papers: ['P1', 'P2'] },
    { id: 'commerce', name: 'Commerce', code: '7100', papers: ['P1', 'P2'] },
    { id: 'sociology', name: 'Sociology', code: '2251', papers: ['P1', 'P2'] },
    { id: 'comp-sci', name: 'Computer Science', code: '2210', papers: ['P1', 'P2'] },
    { id: 'global-persp', name: 'Global Perspectives', code: '2069', papers: ['P1'] },
    { id: 'env-mgmt', name: 'Environmental Management', code: '5014', papers: ['P1', 'P2'] },
    { id: 'food-nutrition', name: 'Food & Nutrition', code: '6065', papers: ['P1', 'P2'] },
    { id: 'travel-tour', name: 'Travel & Tourism', code: '7096', papers: ['P1', 'P2'] },
    { id: 'accounting', name: 'Accounting', code: '7707', papers: ['P1', 'P2'] }
  ],
  'a-level': [
    { id: 'accounting-al', name: 'Accounting', code: '9706', papers: ['P1', 'P2', 'P3'] },
    { id: 'biology-al', name: 'Biology', code: '9700', papers: ['P1', 'P2', 'P3', 'P4', 'P5'] },
    { id: 'business-al', name: 'Business Studies', code: '9609', papers: ['P1', 'P2', 'P3'] },
    { id: 'chemistry-al', name: 'Chemistry', code: '9701', papers: ['P1', 'P2', 'P3', 'P4', 'P5'] },
    { id: 'comp-sci-al', name: 'Computer Science', code: '9618', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'economics-al', name: 'Economics', code: '9708', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'eng-lang-al', name: 'English Language', code: '9093', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'eng-lit-al', name: 'English Literature', code: '9695', papers: ['P3', 'P4', 'P5', 'P6'] },
    { id: 'env-mgmt-al', name: 'Environmental Management', code: '8291', papers: ['P1', 'P2'] },
    { id: 'further-math-al', name: 'Further Mathematics', code: '9231', papers: ['P1', 'P2'] },
    { id: 'history-al', name: 'History', code: '9389', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'law-al', name: 'Law', code: '9084', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'math-al', name: 'Mathematics', code: '9709', papers: ['P1', 'P3', 'S1', 'M1'] },
    { id: 'physics-al', name: 'Physics', code: '9702', papers: ['P1', 'P2', 'P3', 'P4', 'P5'] },
    { id: 'psychology-al', name: 'Psychology', code: '9990', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'sociology-al', name: 'Sociology', code: '9699', papers: ['P1', 'P2', 'P3'] },
    { id: 'thinking-skills-al', name: 'Thinking Skills', code: '9694', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'urdu-al', name: 'Urdu', code: '9676', papers: ['P2', 'P3', 'P4'] }
  ],
  'igcse': [
    { id: 'eng-lang', name: 'English Language (First Language)', code: '0500', papers: ['P1', 'P2'] },
    { id: 'eng-lit', name: 'English Literature', code: '0475', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'urdu-2', name: 'Urdu as a Second Language', code: '0539', papers: ['P1', 'P2'] },
    { id: 'math', name: 'Mathematics (Core and Extended)', code: '0580', papers: ['P1', 'P2', 'P3', 'P4'] },
    { id: 'add-math', name: 'Additional Mathematics', code: '0606', papers: ['P1', 'P2'] },
    { id: 'biology', name: 'Biology', code: '0610', papers: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'] },
    { id: 'chemistry', name: 'Chemistry', code: '0620', papers: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'] },
    { id: 'physics', name: 'Physics', code: '0625', papers: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'] },
    { id: 'comb-sci', name: 'Combined Science', code: '0653', papers: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'] },
    { id: 'pak-studies', name: 'Pakistan Studies', code: '0448', papers: ['P1', 'P2'] },
    { id: 'islamiyat', name: 'Islamiyat', code: '0493', papers: ['P1', 'P2'] },
    { id: 'business', name: 'Business Studies', code: '0450', papers: ['P1', 'P2'] },
    { id: 'economics', name: 'Economics', code: '0455', papers: ['P1', 'P2'] },
    { id: 'sociology', name: 'Sociology', code: '0495', papers: ['P1', 'P2'] },
    { id: 'global-persp', name: 'Global Perspectives', code: '0457', papers: ['P1'] },
    { id: 'comp-sci', name: 'Computer Science', code: '0478', papers: ['P1', 'P2'] },
    { id: 'ict', name: 'Information and Communication Technology (ICT)', code: '0417', papers: ['P1', 'P2', 'P3'] },
    { id: 'geography', name: 'Geography', code: '0460', papers: ['P1', 'P2'] },
    { id: 'env-mgmt', name: 'Environmental Management', code: '0680', papers: ['P1', 'P2'] },
    { id: 'accounting', name: 'Accounting', code: '0452', papers: ['P1', 'P2'] },
    { id: 'eng-2nd-lang', name: 'English as a Second Language', code: '0510', papers: ['P2', 'P4'] }
  ]
};

const BuildYourOwnPage: React.FC = () => {
  const navigate = useNavigate();
  const { addItem } = useCartStore();

  const [showConfetti, setShowConfetti] = useState(false);
  const [showFloatingTile, setShowFloatingTile] = useState(true);
  const [formState, setFormState] = useState<FormState>({
    level: 'o-level',
    subjects: [],
    papers: {},
    binding: 'tape', // Default to tape binding
    bindingOption: 'together',
    notes: '',
    customSubject: '',
  });

  const handleSelectLevel = (level: Level) => {
    setFormState({
      ...formState,
      level,
      subjects: [],
      papers: {},
    });
  };

  const handleToggleSubject = (subjectId: string) => {
    const isSelected = formState.subjects.includes(subjectId);
    let updatedSubjects = [...formState.subjects];
    const updatedPapers = { ...formState.papers };

    if (isSelected) {
      updatedSubjects = updatedSubjects.filter(id => id !== subjectId);
      delete updatedPapers[subjectId];
    } else {
      updatedSubjects.push(subjectId);
      updatedPapers[subjectId] = [];
    }
    setFormState({ ...formState, subjects: updatedSubjects, papers: updatedPapers });
  };
  
  const handleTogglePaper = (subjectId: string, paper: Paper) => {
    const currentPapers = formState.papers[subjectId] || [];
    const isPaperSelected = currentPapers.some(p => p.paper === paper);
    let updatedSubjectPapers;

    if (isPaperSelected) {
      updatedSubjectPapers = currentPapers.filter(p => p.paper !== paper);
    } else {
      const defaultYear = 2025;
      const newPaper: PaperYearRange = {
        paper,
        yearRange: { start: defaultYear - 5, end: defaultYear },
      };
      updatedSubjectPapers = [...currentPapers, newPaper];
    }
    
    setFormState({
      ...formState,
      papers: { ...formState.papers, [subjectId]: updatedSubjectPapers },
    });
  };

  const handleUpdatePaperYear = (subjectId: string, paper: Paper, field: 'start' | 'end', change: number) => {
    const currentPapers = formState.papers[subjectId] || [];
    const paperIndex = currentPapers.findIndex(p => p.paper === paper);
    if (paperIndex === -1) return;

    const updatedPapers = [...currentPapers];
    const currentYear = updatedPapers[paperIndex].yearRange[field];
    const newYear = currentYear + change;
    
    if (newYear > 2025) return;
    if (newYear < 2010) return;
    
    updatedPapers[paperIndex].yearRange[field] = newYear;

    if (field === 'start' && updatedPapers[paperIndex].yearRange.start > updatedPapers[paperIndex].yearRange.end) {
        updatedPapers[paperIndex].yearRange.end = updatedPapers[paperIndex].yearRange.start;
    }
    if (field === 'end' && updatedPapers[paperIndex].yearRange.end < updatedPapers[paperIndex].yearRange.start) {
        updatedPapers[paperIndex].yearRange.start = updatedPapers[paperIndex].yearRange.end;
    }

    setFormState({
      ...formState,
      papers: { ...formState.papers, [subjectId]: updatedPapers },
    });
  };

  const calculatePrice = useMemo(() => {
    let basePrice = 0;
    let totalPapers = 0;
    formState.subjects.forEach(subjectId => {
      const papers = formState.papers[subjectId] || [];
      papers.forEach(paperInfo => {
        const yearCount = paperInfo.yearRange.end - paperInfo.yearRange.start + 1;
        const paperPrice = pricing[formState.level]?.[subjectId]?.[paperInfo.paper] ?? 0;
        basePrice += paperPrice * (yearCount > 0 ? yearCount : 0);
        totalPapers += 1;
      });
    });

    // Only add tape binding charge (50 PKR per paper) - removed ring binding
    if (formState.binding === 'tape') {
      basePrice += 50 * totalPapers;
    }
    return basePrice;
  }, [formState]);

  const handleAddToCart = () => {
    if (formState.subjects.length === 0) {
      toast.error('Please select at least one subject.');
      return;
    }
    const hasSelectedPapers = formState.subjects.some(sid => formState.papers[sid]?.length > 0);
    if (!hasSelectedPapers) {
      toast.error('Please select at least one paper for your chosen subjects.');
      return;
    }

    const levelLabel = formState.level === 'o-level' ? 'O Level' : formState.level === 'a-level' ? 'A Level' : 'IGCSE';
    const allSubjects = subjects[formState.level];
    
    const customPackage = {
      id: `custom-${Date.now()}`,
      type: 'custom' as const,
      name: `Custom ${levelLabel} Package`,
      price: calculatePrice,
      details: {
        level: levelLabel,
        subjects: formState.subjects.map(subjectId => {
          const subject = allSubjects.find(s => s.id === subjectId);
          return {
            name: subject?.name,
            code: subject?.code,
            papers: formState.papers[subjectId]?.map(p => ({
              paper: p.paper,
              yearRange: `${p.yearRange.start}-${p.yearRange.end}`,
            })) || [],
          };
        }),
        binding: formState.binding === 'tape' ? 'Tape Binding (together)' : 'No Binding',
        notes: formState.notes,
        customSubject: formState.customSubject,
      },
    };

    addItem(customPackage);
    toast.success('Custom package added to cart!');
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 5000);
  };

  const getSubjectById = (subjectId: string): Subject | undefined => {
    return subjects[formState.level].find(s => s.id === subjectId);
  };

  const levelConfig = {
    'o-level': { color: COLORS.complementary.coral, name: 'O Level', icon: '📘' },
    'a-level': { color: COLORS.teal.primary, name: 'A Level', icon: '📗' },
    'igcse': { color: COLORS.complementary.lavender, name: 'IGCSE', icon: '📙' },
  };

  const getLevelColor = (level: Level) => {
    return level === 'o-level' ? COLORS.complementary.coral : 
           level === 'a-level' ? COLORS.teal.primary : 
           COLORS.complementary.lavender;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50/30 via-white to-blue-50/20 font-sans">
      {showConfetti && <Confetti recycle={false} numberOfPieces={300} />}
      
      {/* Floating Custom Requests Tile */}
      {showFloatingTile && (
        <motion.div
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 100 }}
          transition={{ duration: 0.3, delay: 2 }}
          className="fixed bottom-6 right-6 z-50"
        >
          <div className="bg-gradient-to-r from-teal-500 to-teal-600 text-white px-4 py-3 rounded-full shadow-lg shadow-teal-500/30 flex items-center space-x-3 hover:shadow-xl transition-all hover:scale-105">
            <Mail className="h-4 w-4 text-teal-100" />
            <span className="text-sm font-medium whitespace-nowrap">Need something special?</span>
            <a
              href="https://mail.google.com/mail/?view=cm&fs=1&to=web.mtpaperhub@gmail.com&su=Custom%20Request&body=Hi%20MTPaperhub,%0D%0A%0D%0AI%20need%20help%20with:%0D%0A%0D%0A[Please%20describe%20what%20you%20need]%0D%0A%0D%0AThank%20you!"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-teal-600 px-3 py-1 rounded-full text-xs font-medium hover:bg-teal-50 transition-colors shadow-sm"
            >
              Email Us
            </a>
            <button
              onClick={() => setShowFloatingTile(false)}
              className="text-teal-200 hover:text-white transition-colors ml-1"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        </motion.div>
      )}
      
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg sticky top-0 z-30 border-b border-teal-100 shadow-sm">
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-teal-100 rounded-lg">
                <Package className="h-6 w-6 text-teal-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-teal-600 to-teal-700 bg-clip-text text-transparent">
                  Build Your Own Package
                </h1>
                <p className="text-xs text-teal-500 font-medium">Create your perfect exam paper bundle</p>
              </div>
            </div>
            <button 
              onClick={() => navigate('/cart')}
              className="relative group p-3 rounded-full bg-gradient-to-r from-teal-500 to-teal-600 text-white shadow-lg shadow-teal-500/30 hover:shadow-xl hover:shadow-teal-500/40 hover:scale-105 transition-all"
            >
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                0
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Progress Indicator */}
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="flex items-center gap-2 mb-2">
          <div className="h-2 w-2 rounded-full bg-teal-500"></div>
          <span className="text-xs font-medium text-teal-600">Step-by-step builder</span>
        </div>
      </div>

      <main className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* Left Column: Controls */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* 1. Level Selection */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-teal-100"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-teal-100 rounded-lg">
                  <Layers className="h-5 w-5 text-teal-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-800">Step 1: Select Exam Level</h2>
                  <p className="text-slate-500 text-sm">Choose your exam level to get started</p>
                </div>
              </div>
              
              {/* Level Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(levelConfig).map(([level, config]) => (
                  <motion.button
                    key={level}
                    onClick={() => handleSelectLevel(level as Level)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`p-5 rounded-xl border-2 text-left transition-all duration-300 ${
                      formState.level === level
                        ? 'ring-2 ring-offset-2 shadow-lg'
                        : 'hover:shadow-md'
                    }`}
                    style={{
                      backgroundColor: formState.level === level ? `${config.color}10` : COLORS.neutral.white,
                      borderColor: formState.level === level ? config.color : COLORS.neutral.gray,
                      ringColor: config.color
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-2xl mb-2">{config.icon}</div>
                        <h3 className="font-bold text-slate-800">{config.name}</h3>
                        <p className="text-xs text-slate-500 mt-1">
                          {subjects[level as Level].length} subjects available
                        </p>
                      </div>
                      {formState.level === level && (
                        <div className="p-1 rounded-full" style={{ backgroundColor: config.color }}>
                          <Check className="h-4 w-4 text-white" />
                        </div>
                      )}
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* 2. Subject Selection */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-teal-100"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-teal-100 rounded-lg">
                  <BookOpen className="h-5 w-5 text-teal-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-800">Step 2: Choose Subjects</h2>
                  <p className="text-slate-500 text-sm">Select all the subjects you need</p>
                </div>
                <span className="ml-auto bg-teal-100 text-teal-700 text-sm font-medium px-3 py-1 rounded-full">
                  {formState.subjects.length} selected
                </span>
              </div>
              
              <motion.div
                key={formState.level}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"
              >
                {subjects[formState.level].map((subject) => {
                  const isSelected = formState.subjects.includes(subject.id);
                  const levelColor = getLevelColor(formState.level);
                  
                  return (
                    <motion.button
                      key={subject.id}
                      onClick={() => handleToggleSubject(subject.id)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`p-4 rounded-xl text-left border-2 transition-all duration-200 group ${
                        isSelected ? 'shadow-md' : 'hover:shadow-sm'
                      }`}
                      style={{
                        backgroundColor: isSelected ? `${levelColor}10` : COLORS.neutral.white,
                        borderColor: isSelected ? levelColor : COLORS.neutral.gray
                      }}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <p className="font-semibold text-slate-800 text-sm group-hover:text-teal-700 transition-colors">
                            {subject.name}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-1 rounded">
                              {subject.code}
                            </span>
                            <span className="text-xs text-slate-400">
                              {subject.papers.length} papers
                            </span>
                          </div>
                        </div>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all ${
                          isSelected 
                            ? 'border-teal-500 bg-teal-500' 
                            : 'border-slate-300 group-hover:border-teal-300'
                        }`}>
                          {isSelected && <Check className="w-3 h-3 text-white" />}
                        </div>
                      </div>
                    </motion.button>
                  );
                })}
              </motion.div>
            </motion.div>

            {/* 3. Paper Configuration */}
            <AnimatePresence>
              {formState.subjects.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white p-6 rounded-2xl shadow-sm border border-teal-100 space-y-6"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-teal-100 rounded-lg">
                      <Calendar className="h-5 w-5 text-teal-600" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-slate-800">Step 3: Configure Papers</h2>
                      <p className="text-slate-500 text-sm">Select papers and year ranges for each subject</p>
                    </div>
                  </div>

                  {formState.subjects.map(subjectId => {
                    const subject = getSubjectById(subjectId);
                    if (!subject) return null;
                    const selectedPapers = formState.papers[subjectId] || [];

                    return (
                      <motion.div 
                        key={subjectId}
                        layout
                        className="p-5 rounded-xl bg-gradient-to-r from-teal-50/50 to-white border border-teal-100"
                      >
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <h3 className="font-bold text-slate-800">{subject.name}</h3>
                            <p className="text-sm text-teal-600 font-medium">Code: {subject.code}</p>
                          </div>
                          <button 
                            onClick={() => handleToggleSubject(subjectId)}
                            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Paper Selection */}
                        <div className="mb-4">
                          <p className="text-sm font-medium text-slate-700 mb-3">Available Papers:</p>
                          <div className="flex flex-wrap gap-2">
                            {subject.papers.map(paper => {
                              const isPaperSelected = selectedPapers.some(p => p.paper === paper);
                              return (
                                <motion.button
                                  key={paper}
                                  onClick={() => handleTogglePaper(subjectId, paper)}
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  className={`px-4 py-2 text-sm font-medium rounded-lg border transition-all ${
                                    isPaperSelected
                                      ? 'bg-teal-500 text-white border-teal-500 shadow-md'
                                      : 'bg-white text-slate-700 border-slate-300 hover:border-teal-300'
                                  }`}
                                >
                                  {paper}
                                </motion.button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Year Range Configuration */}
                        <AnimatePresence>
                          {selectedPapers.length > 0 && (
                            <motion.div 
                              layout
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="space-y-4 mt-6"
                            >
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {selectedPapers.map(({ paper, yearRange }) => {
                                  const paperPrice = pricing[formState.level]?.[subjectId]?.[paper] || 0;
                                  const yearCount = yearRange.end - yearRange.start + 1;
                                  const totalPaperPrice = paperPrice * yearCount;
                                  
                                  return (
                                    <motion.div 
                                      key={paper}
                                      layout
                                      className="bg-white p-4 rounded-xl border border-teal-100 shadow-sm"
                                    >
                                      <div className="flex items-center justify-between mb-4">
                                        <div className="flex items-center gap-2">
                                          <Bookmark className="w-4 h-4 text-teal-500" />
                                          <span className="font-bold text-teal-700">{paper}</span>
                                        </div>
                                        <span className="text-sm font-bold text-teal-600">
                                          PKR {totalPaperPrice.toLocaleString()}
                                        </span>
                                      </div>

                                      {/* Year Controls */}
                                      <div className="space-y-3">
                                        <div className="flex items-center justify-between">
                                          <span className="text-sm text-slate-600">Start Year</span>
                                          <div className="flex items-center gap-3">
                                            <button 
                                              onClick={() => handleUpdatePaperYear(subjectId, paper, 'start', -1)}
                                              className="p-1.5 rounded-full bg-teal-100 text-teal-600 hover:bg-teal-200 transition-colors"
                                            >
                                              <Minus className="w-3 h-3" />
                                            </button>
                                            <span className="font-mono font-bold text-slate-800 w-12 text-center">
                                              {yearRange.start}
                                            </span>
                                            <button 
                                              onClick={() => handleUpdatePaperYear(subjectId, paper, 'start', 1)}
                                              className="p-1.5 rounded-full bg-teal-100 text-teal-600 hover:bg-teal-200 transition-colors"
                                            >
                                              <Plus className="w-3 h-3" />
                                            </button>
                                          </div>
                                        </div>

                                        <div className="flex items-center justify-between">
                                          <span className="text-sm text-slate-600">End Year</span>
                                          <div className="flex items-center gap-3">
                                            <button 
                                              onClick={() => handleUpdatePaperYear(subjectId, paper, 'end', -1)}
                                              className="p-1.5 rounded-full bg-teal-100 text-teal-600 hover:bg-teal-200 transition-colors"
                                            >
                                              <Minus className="w-3 h-3" />
                                            </button>
                                            <span className="font-mono font-bold text-slate-800 w-12 text-center">
                                              {yearRange.end}
                                            </span>
                                            <button 
                                              onClick={() => handleUpdatePaperYear(subjectId, paper, 'end', 1)}
                                              className="p-1.5 rounded-full bg-teal-100 text-teal-600 hover:bg-teal-200 transition-colors"
                                            >
                                              <Plus className="w-3 h-3" />
                                            </button>
                                          </div>
                                        </div>

                                        <div className="pt-3 border-t border-slate-100">
                                          <p className="text-xs text-slate-500 text-center">
                                            {paperPrice} PKR × {yearCount} years
                                          </p>
                                        </div>
                                      </div>
                                    </motion.div>
                                  );
                                })}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>

            {/* 4. Final Touches */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-teal-100"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-teal-100 rounded-lg">
                  <Sparkles className="h-5 w-5 text-teal-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-800">Step 4: Final Touches</h2>
                  <p className="text-slate-500 text-sm">Add binding and any special notes</p>
                </div>
              </div>
              
              {/* Binding Options - Simplified without ring binding */}
              <div className="mb-8">
                <h3 className="font-bold text-slate-700 mb-4">📦 Binding Options</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    onClick={() => setFormState({...formState, binding: 'none'})}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${
                      formState.binding === 'none' 
                        ? 'border-teal-500 bg-teal-50 ring-2 ring-teal-500/20' 
                        : 'border-slate-200 hover:border-teal-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        formState.binding === 'none' ? 'border-teal-500 bg-teal-500' : 'border-slate-300'
                      }`}>
                        {formState.binding === 'none' && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="font-semibold text-slate-800">No Binding</span>
                    </div>
                    <p className="text-sm text-slate-600 pl-9">Simple loose papers</p>
                    <p className="text-sm font-bold text-green-600 mt-2 pl-9">Free</p>
                  </button>

                  <button 
                    onClick={() => setFormState({...formState, binding: 'tape'})}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${
                      formState.binding === 'tape' 
                        ? 'border-teal-500 bg-teal-50 ring-2 ring-teal-500/20' 
                        : 'border-slate-200 hover:border-teal-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        formState.binding === 'tape' ? 'border-teal-500 bg-teal-500' : 'border-slate-300'
                      }`}>
                        {formState.binding === 'tape' && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="font-semibold text-slate-800">Tape Binding</span>
                    </div>
                    <p className="text-sm text-slate-600 pl-9">Simple and cost-effective</p>
                    <p className="text-sm font-bold text-teal-600 mt-2 pl-9">+50 PKR per paper</p>
                    <p className="text-xs text-slate-500 mt-1 pl-9">Most popular choice</p>
                  </button>
                </div>
              </div>
              
              {/* Special Notes */}
              <div>
                <h3 className="font-bold text-slate-700 mb-3">📝 Special Notes</h3>
                <textarea
                  value={formState.notes}
                  onChange={(e) => setFormState({...formState, notes: e.target.value})}
                  className="w-full px-4 py-3 border border-teal-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-white/50 resize-none"
                  rows={4}
                  placeholder="Any special instructions, custom requirements, or additional notes for your order..."
                />
                <p className="text-xs text-slate-500 mt-2">
                  Let us know if you need anything special or have specific requirements.
                </p>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              <div className="bg-gradient-to-br from-white to-teal-50/30 rounded-2xl shadow-lg border border-teal-100 overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-gradient-to-r from-teal-500 to-teal-600 rounded-lg">
                      <Package className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-slate-800">Your Package Summary</h2>
                      <p className="text-sm text-teal-600">Review your custom selection</p>
                    </div>
                  </div>
                  
                  {/* Level & Binding Info */}
                  <div className="mb-6 p-4 bg-white rounded-xl border border-teal-100">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-500 mb-1">Level</p>
                        <p className="font-bold text-slate-800 capitalize">
                          {levelConfig[formState.level].name}
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500 mb-1">Binding</p>
                        <p className="font-bold text-slate-800 capitalize">
                          {formState.binding === 'tape' ? 'Tape Binding' : 'No Binding'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Subjects List */}
                  <div className="mb-4">
                    <h3 className="font-bold text-slate-700 mb-3">Selected Subjects</h3>
                    <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                      {formState.subjects.length > 0 ? (
                        formState.subjects.map(sid => {
                          const subject = getSubjectById(sid);
                          const papers = formState.papers[sid] || [];
                          
                          return (
                            <div key={sid} className="p-3 bg-white rounded-lg border border-teal-100">
                              <div className="flex justify-between items-start">
                                <div>
                                  <p className="font-semibold text-slate-800 text-sm">{subject?.name}</p>
                                  <p className="text-xs text-teal-600 mt-1">{subject?.code}</p>
                                </div>
                                <span className="text-xs font-bold bg-teal-100 text-teal-700 px-2 py-1 rounded-full">
                                  {papers.length} papers
                                </span>
                              </div>
                              {papers.length > 0 && (
                                <div className="mt-2 pt-2 border-t border-slate-100">
                                  <p className="text-xs text-slate-500 mb-1">Papers:</p>
                                  <div className="flex flex-wrap gap-1">
                                    {papers.map(({ paper, yearRange }) => (
                                      <span key={paper} className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded">
                                        {paper} ({yearRange.start}-{yearRange.end})
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        <div className="text-center py-8">
                          <BookOpen className="mx-auto h-12 w-12 text-slate-300 mb-3" />
                          <p className="text-sm text-slate-500">No subjects selected yet</p>
                          <p className="text-xs text-slate-400 mt-1">Start building your package above!</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Total & Add to Cart */}
                <div className="p-6 bg-gradient-to-r from-teal-500/10 via-teal-100/20 to-white rounded-b-2xl border-t border-teal-200">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <p className="text-sm text-teal-600 font-medium">Total Price</p>
                      <p className="text-xs text-slate-500">Including all selections</p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-teal-700 bg-clip-text text-transparent">
                        PKR {calculatePrice.toLocaleString()}
                      </p>
                      <p className="text-xs text-teal-600 mt-1">
                        {formState.binding === 'tape' ? 'Includes tape binding' : 'No binding charges'}
                      </p>
                    </div>
                  </div>
                  
                  <motion.button 
                    onClick={handleAddToCart}
                    disabled={formState.subjects.length === 0}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`w-full flex items-center justify-center gap-3 text-white font-bold py-4 px-6 rounded-xl transition-all duration-300 shadow-lg ${
                      formState.subjects.length > 0
                        ? 'bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 hover:shadow-xl shadow-teal-500/30'
                        : 'bg-slate-300 cursor-not-allowed shadow-none'
                    }`}
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Add to Cart
                    <ChevronRight className="w-4 h-4" />
                  </motion.button>
                  
                  <p className="text-xs text-center text-slate-500 mt-4">
                    You can edit your package anytime before checkout
                  </p>
                </div>
              </div>
              
              {/* Help Card */}
              <div className="p-4 bg-gradient-to-r from-teal-50 to-teal-100/50 text-teal-800 rounded-xl border border-teal-200">
                <div className="flex gap-3">
                  <HelpCircle className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-teal-700 mb-1">Need help?</p>
                    <p className="text-sm text-teal-600">
                      Can't find a subject or have special requirements? Add your request in the notes section above.
                    </p>
                  </div>
                </div>
              </div>

              {/* Stats Card */}
              <div className="p-4 bg-white rounded-xl border border-teal-100">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-teal-600">{formState.subjects.length}</p>
                    <p className="text-xs text-slate-500">Subjects</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-teal-600">
                      {Object.values(formState.papers).flat().length}
                    </p>
                    <p className="text-xs text-slate-500">Papers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// This export sends the page component to the router
export default BuildYourOwnPage;