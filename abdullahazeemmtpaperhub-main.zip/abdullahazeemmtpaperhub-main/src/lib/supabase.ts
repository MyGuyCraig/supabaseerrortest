import { createClient } from '@supabase/supabase-js';

// Hardcoded Supabase credentials
const supabaseUrl = 'https://jrhwjvaresmejwjfenup.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpyaHdqdmFyZXNtZWp3amZlbnVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY0MzM5OTksImV4cCI6MjA3MjAwOTk5OX0.JrpKORMPLMAVHBkhkUpBbmRq8DjseAPYyifKtqCOlFA';

// Supabase is always considered configured now
export const isSupabaseConfigured = true;

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

